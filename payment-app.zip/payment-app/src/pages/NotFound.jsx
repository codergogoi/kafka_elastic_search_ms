const NotFound = () => {
  return (
    <div style={{ padding: "20px" }}>
      <h1>404 - Page Not Found</h1>
    </div>
  );
};

export default NotFound;
